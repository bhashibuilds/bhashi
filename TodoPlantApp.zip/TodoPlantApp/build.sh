#!/bin/bash

# Build script for TodoPlantApp
echo "🌱 Building Todo Plant App..."

cd "$(dirname "$0")"

# Check if Xcode is available
if ! command -v xcodebuild &> /dev/null; then
    echo "❌ Error: Xcode command line tools are not installed."
    echo "Please install Xcode from the App Store or run: xcode-select --install"
    exit 1
fi

# Build the project
echo "🔨 Building the project..."
xcodebuild -project TodoPlantApp.xcodeproj -scheme TodoPlantApp -configuration Release -derivedDataPath ./build

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "📱 Your app is ready at: ./build/Build/Products/Release/TodoPlantApp.app"
    echo ""
    echo "To run the app, either:"
    echo "1. Double-click the app in Finder"
    echo "2. Run: open ./build/Build/Products/Release/TodoPlantApp.app"
else
    echo "❌ Build failed. Please check the errors above."
    exit 1
fi
