import SwiftUI

struct ContentView: View {
    @StateObject private var gameLogic = GameLogic()
    @State private var showingTimerSetup = false
    @State private var timerMinutes = 30
    
    var body: some View {
        VStack(spacing: 0) {
            // Header with app title and controls
            HStack {
                VStack(alignment: .leading) {
                    Text("🌱 Todo Plant")
                        .font(.title)
                        .bold()
                    Text("Complete tasks to grow your plant!")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                // Control buttons
                HStack(spacing: 10) {
                    Button("Set Timer") {
                        showingTimerSetup = true
                    }
                    .disabled(gameLogic.timerState == .running)
                    
                    Button("Reset Game") {
                        gameLogic.resetGame()
                    }
                    .foregroundColor(.red)
                }
                .font(.caption)
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            
            HStack(alignment: .top, spacing: 20) {
                // Left side: Todo List
                VStack {
                    TodoListView(gameLogic: gameLogic)
                }
                .frame(width: 350)
                
                Divider()
                
                // Right side: Plant
                VStack {
                    PlantView(plantModel: gameLogic.plantModel)
                }
                .frame(width: 300)
            }
            .padding()
        }
        .frame(width: 700, height: 600)
        .sheet(isPresented: $showingTimerSetup) {
            TimerSetupView(
                timerMinutes: $timerMinutes,
                onSetTimer: { minutes in
                    gameLogic.setTimer(minutes: minutes)
                    showingTimerSetup = false
                }
            )
        }
    }
}

struct TimerSetupView: View {
    @Binding var timerMinutes: Int
    let onSetTimer: (Int) -> Void
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Set Timer")
                .font(.title2)
                .bold()
            
            Text("Set a time limit to complete all your tasks. If you don't finish in time, your plant will die! 💀")
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
            
            VStack {
                HStack {
                    Text("Minutes:")
                    TextField("Minutes", value: $timerMinutes, format: .number)
                        .textFieldStyle(.roundedBorder)
                        .frame(width: 80)
                }
                
                Slider(value: Binding(
                    get: { Double(timerMinutes) },
                    set: { timerMinutes = Int($0) }
                ), in: 5...120, step: 5)
                
                Text("\(timerMinutes) minutes")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            HStack(spacing: 15) {
                Button("Cancel") {
                    dismiss()
                }
                .foregroundColor(.secondary)
                
                Button("Set Timer") {
                    onSetTimer(timerMinutes)
                }
                .bold()
                .disabled(timerMinutes < 5)
            }
        }
        .padding(30)
        .frame(width: 400)
    }
}

#Preview {
    ContentView()
}
