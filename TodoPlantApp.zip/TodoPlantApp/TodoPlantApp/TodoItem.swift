import SwiftUI

// Model for individual todo items
struct TodoItem: Identifiable, Codable {
    let id = UUID()
    var title: String
    var isCompleted: Bool = false
    var dateCreated: Date = Date()
    
    init(title: String) {
        self.title = title
    }
}
