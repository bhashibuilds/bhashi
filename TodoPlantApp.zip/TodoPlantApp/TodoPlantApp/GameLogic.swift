import SwiftUI
import Foundation

enum TimerState {
    case stopped
    case running
    case expired
}

// Main game logic coordinator
class GameLogic: ObservableObject {
    @Published var plantModel = PlantModel()
    @Published var todoItems: [TodoItem] = []
    @Published var timerDuration: TimeInterval = 0 // 0 means no timer
    @Published var timeRemaining: TimeInterval = 0
    @Published var timerState: TimerState = .stopped
    
    private var timer: Timer?
    
    var allTasksCompleted: Bool {
        !todoItems.isEmpty && todoItems.allSatisfy { $0.isCompleted }
    }
    
    var timeRemainingText: String {
        let minutes = Int(timeRemaining) / 60
        let seconds = Int(timeRemaining) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    func addTodoItem(title: String) {
        let newItem = TodoItem(title: title)
        todoItems.append(newItem)
        
        // Start with at least one task to prevent immediate plant death
        if todoItems.count == 1 && timerDuration > 0 && timerState == .stopped {
            timeRemaining = timerDuration
        }
    }
    
    func deleteTodoItem(_ item: TodoItem) {
        todoItems.removeAll { $0.id == item.id }
        checkGameState()
    }
    
    func toggleTodoItem(_ item: TodoItem) {
        if let index = todoItems.firstIndex(where: { $0.id == item.id }) {
            todoItems[index].isCompleted.toggle()
            
            // Grow plant when task is completed
            if todoItems[index].isCompleted {
                plantModel.growPlant()
            }
            
            checkGameState()
        }
    }
    
    func setTimer(minutes: Int) {
        timerDuration = TimeInterval(minutes * 60)
        timeRemaining = timerDuration
        timerState = .stopped
    }
    
    func startTimer() {
        guard timerDuration > 0 && !todoItems.isEmpty else { return }
        
        timerState = .running
        timeRemaining = timerDuration
        
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            DispatchQueue.main.async {
                self.updateTimer()
            }
        }
    }
    
    private func updateTimer() {
        if timeRemaining > 0 {
            timeRemaining -= 1
        } else {
            timerExpired()
        }
    }
    
    private func timerExpired() {
        timer?.invalidate()
        timerState = .expired
        
        // Kill plant if not all tasks are completed
        if !allTasksCompleted {
            plantModel.killPlant()
        }
    }
    
    func resetGame() {
        timer?.invalidate()
        todoItems.removeAll()
        plantModel.resetPlant()
        timerState = .stopped
        timeRemaining = timerDuration
    }
    
    private func checkGameState() {
        // If all tasks completed, stop timer
        if allTasksCompleted && timerState == .running {
            timer?.invalidate()
            timerState = .stopped
        }
        
        // If no tasks remain and timer was running, kill plant
        if todoItems.isEmpty && timerState == .running {
            timerExpired()
        }
    }
    
    deinit {
        timer?.invalidate()
    }
}
