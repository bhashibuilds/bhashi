import SwiftUI

struct TodoListView: View {
    @ObservedObject var gameLogic: GameLogic
    @State private var newTaskTitle: String = ""
    @State private var showingAddTask: Bool = false
    
    var body: some View {
        VStack(spacing: 15) {
            // Header
            HStack {
                Text("Todo List")
                    .font(.title2)
                    .bold()
                
                Spacer()
                
                Button(action: { showingAddTask = true }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                        .foregroundColor(.blue)
                }
                .disabled(gameLogic.timerState == .expired)
            }
            
            // Timer display
            if gameLogic.timerDuration > 0 {
                HStack {
                    Text("Time Remaining:")
                        .font(.caption)
                    
                    Text(gameLogic.timeRemainingText)
                        .font(.title3)
                        .bold()
                        .foregroundColor(gameLogic.timerState == .running ? 
                                       (gameLogic.timeRemaining < 300 ? .red : .orange) : .primary)
                    
                    Spacer()
                    
                    if gameLogic.timerState == .stopped {
                        Button("Start Timer") {
                            gameLogic.startTimer()
                        }
                        .font(.caption)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
            }
            
            // Todo items list
            ScrollView {
                LazyVStack(spacing: 8) {
                    ForEach(gameLogic.todoItems) { item in
                        TodoItemRow(
                            item: item,
                            onToggle: { gameLogic.toggleTodoItem(item) },
                            onDelete: { gameLogic.deleteTodoItem(item) }
                        )
                    }
                }
                .padding(.horizontal, 5)
            }
            .frame(maxHeight: 300)
            
            // Add task form
            if showingAddTask {
                VStack {
                    HStack {
                        TextField("Enter new task...", text: $newTaskTitle)
                            .textFieldStyle(.roundedBorder)
                        
                        Button("Add") {
                            if !newTaskTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                gameLogic.addTodoItem(title: newTaskTitle)
                                newTaskTitle = ""
                                showingAddTask = false
                            }
                        }
                        .disabled(newTaskTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        
                        Button("Cancel") {
                            newTaskTitle = ""
                            showingAddTask = false
                        }
                    }
                }
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(10)
            }
            
            // Status messages
            if gameLogic.todoItems.isEmpty {
                Text("Add at least one task to start growing your plant! 🌱")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .italic()
                    .multilineTextAlignment(.center)
                    .padding()
            } else if gameLogic.allTasksCompleted {
                Text("🎉 All tasks completed! Your plant is happy!")
                    .font(.subheadline)
                    .foregroundColor(.green)
                    .bold()
                    .multilineTextAlignment(.center)
                    .padding()
            }
        }
        .padding()
    }
}

struct TodoItemRow: View {
    let item: TodoItem
    let onToggle: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack {
            Button(action: onToggle) {
                Image(systemName: item.isCompleted ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(item.isCompleted ? .green : .gray)
                    .font(.title3)
            }
            .buttonStyle(.plain)
            
            Text(item.title)
                .strikethrough(item.isCompleted)
                .foregroundColor(item.isCompleted ? .secondary : .primary)
            
            Spacer()
            
            Button(action: onDelete) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
                    .font(.caption)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(item.isCompleted ? Color.green.opacity(0.1) : Color.gray.opacity(0.05))
        )
    }
}
