import SwiftUI

// Plant types available for selection
enum PlantType: String, CaseIterable, Identifiable {
    case sunflower = "🌻"
    case tree = "🌳"
    case flower = "🌸"
    case cactus = "🌵"
    case rose = "🌹"
    case tulip = "🌷"
    
    var id: String { self.rawValue }
    
    var name: String {
        switch self {
        case .sunflower: return "Sunflower"
        case .tree: return "Oak Tree"
        case .flower: return "Cherry Blossom"
        case .cactus: return "Desert Cactus"
        case .rose: return "Red Rose"
        case .tulip: return "Spring Tulip"
        }
    }
    
    // Different growth stages for each plant
    var growthStages: [String] {
        switch self {
        case .sunflower:
            return ["🌱", "🌿", "🌾", "🌻"]
        case .tree:
            return ["🌱", "🌿", "🌳", "🌳"]
        case .flower:
            return ["🌱", "🌿", "🌸", "🌸"]
        case .cactus:
            return ["🌱", "🌵", "🌵", "🌵"]
        case .rose:
            return ["🌱", "🌿", "🥀", "🌹"]
        case .tulip:
            return ["🌱", "🌿", "🌷", "🌷"]
        }
    }
}

// Model for plant state
class PlantModel: ObservableObject {
    @Published var selectedPlantType: PlantType = .sunflower
    @Published var currentGrowthStage: Int = 0
    @Published var isDead: Bool = false
    @Published var isFullyGrown: Bool = false
    
    var currentPlantEmoji: String {
        if isDead {
            return "💀"
        }
        
        let stages = selectedPlantType.growthStages
        let stageIndex = min(currentGrowthStage, stages.count - 1)
        return stages[stageIndex]
    }
    
    var growthProgress: Double {
        if isDead { return 0.0 }
        let maxStages = selectedPlantType.growthStages.count - 1
        return maxStages > 0 ? Double(currentGrowthStage) / Double(maxStages) : 0.0
    }
    
    func growPlant() {
        if !isDead && !isFullyGrown {
            currentGrowthStage += 1
            if currentGrowthStage >= selectedPlantType.growthStages.count - 1 {
                isFullyGrown = true
            }
        }
    }
    
    func killPlant() {
        isDead = true
    }
    
    func resetPlant() {
        currentGrowthStage = 0
        isDead = false
        isFullyGrown = false
    }
    
    func selectPlant(_ plantType: PlantType) {
        selectedPlantType = plantType
        resetPlant()
    }
}
