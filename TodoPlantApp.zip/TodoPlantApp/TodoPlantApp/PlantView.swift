import SwiftUI

struct PlantView: View {
    @ObservedObject var plantModel: PlantModel
    
    var body: some View {
        VStack(spacing: 20) {
            // Plant display
            VStack {
                Text(plantModel.currentPlantEmoji)
                    .font(.system(size: 80))
                    .scaleEffect(plantModel.isDead ? 0.8 : 1.0)
                    .animation(.easeInOut(duration: 0.5), value: plantModel.currentGrowthStage)
                    .animation(.easeInOut(duration: 0.3), value: plantModel.isDead)
                
                Text(plantModel.selectedPlantType.name)
                    .font(.headline)
                    .foregroundColor(plantModel.isDead ? .red : .primary)
                
                if plantModel.isDead {
                    Text("💀 Plant Died!")
                        .font(.title2)
                        .foregroundColor(.red)
                        .bold()
                } else if plantModel.isFullyGrown {
                    Text("🎉 Fully Grown!")
                        .font(.title2)
                        .foregroundColor(.green)
                        .bold()
                } else {
                    Text("Growth Progress")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            // Growth progress bar
            if !plantModel.isDead {
                ProgressView(value: plantModel.growthProgress)
                    .progressViewStyle(LinearProgressViewStyle(tint: .green))
                    .frame(width: 200)
                    .background(Color.gray.opacity(0.3))
                    .cornerRadius(10)
            }
            
            // Plant selection (only show at start or when plant is dead)
            if plantModel.currentGrowthStage == 0 || plantModel.isDead {
                VStack {
                    Text("Choose Your Plant")
                        .font(.headline)
                        .padding(.top)
                    
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 15) {
                        ForEach(PlantType.allCases) { plantType in
                            Button(action: {
                                plantModel.selectPlant(plantType)
                            }) {
                                VStack {
                                    Text(plantType.growthStages.last ?? "")
                                        .font(.system(size: 40))
                                    Text(plantType.name)
                                        .font(.caption)
                                        .multilineTextAlignment(.center)
                                }
                                .padding(10)
                                .background(
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(plantModel.selectedPlantType == plantType ? Color.blue.opacity(0.3) : Color.gray.opacity(0.1))
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal)
                }
            }
        }
        .padding()
    }
}
