#!/bin/bash

# Alternative build script using Swift Package Manager
echo "🌱 Building Todo Plant App with Swift Package Manager..."

cd "$(dirname "$0")"

# Check if Swift is available
if ! command -v swift &> /dev/null; then
    echo "❌ Error: Swift is not installed or not in PATH."
    echo "Please install Xcode from the App Store."
    exit 1
fi

# Build the project
echo "🔨 Building the project..."
swift build -c release

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "📱 Your executable is ready at: ./.build/release/TodoPlantApp"
    echo ""
    echo "To run the app:"
    echo "./.build/release/TodoPlantApp"
else
    echo "❌ Build failed. Please check the errors above."
    exit 1
fi
