# 🌱 Todo Plant App

A gamified todo list app for macOS that grows a virtual plant as you complete tasks!

## Features

### 🎯 Core Functionality
- **Todo List Management**: Add, complete, and delete tasks
- **Plant Growth System**: Your plant grows with each completed task
- **Timer Challenge**: Set a timer and complete all tasks before it expires
- **Plant Selection**: Choose from 6 different plant types before starting

### 🌿 Plant Types Available
- 🌻 **Sunflower**: Classic and cheerful
- 🌳 **Oak Tree**: Strong and majestic  
- 🌸 **Cherry Blossom**: Delicate and beautiful
- 🌵 **Desert Cactus**: Resilient and unique
- 🌹 **Red Rose**: Elegant and romantic
- 🌷 **Spring Tulip**: Fresh and vibrant

### 🎮 Game Mechanics
- **Growth Stages**: Each plant has 4 growth stages (🌱 → 🌿 → mature → fully grown)
- **Task Completion**: Every completed task advances your plant's growth
- **Timer Challenge**: Optional timer adds urgency - complete all tasks or your plant dies! 💀
- **Minimum Tasks**: You need at least 1 task to prevent immediate plant death
- **Reset Function**: Start fresh with a new plant and task list anytime

### ⏰ Timer System
- Set timer from 5 to 120 minutes
- Visual countdown with color coding (green → orange → red)
- Plant dies if you don't complete all tasks before timer expires
- Timer stops automatically when all tasks are completed

## How to Use

1. **Choose Your Plant**: Select from 6 different plant types
2. **Add Tasks**: Click the "+" button to add todo items (minimum 1 required)
3. **Set Timer** (Optional): Click "Set Timer" to add time pressure
4. **Start Timer**: Begin the countdown challenge
5. **Complete Tasks**: Check off tasks to grow your plant
6. **Watch It Grow**: See your plant progress through growth stages
7. **Celebrate**: Enjoy your fully grown plant when all tasks are done!

## Requirements

- macOS 14.0 or later
- Xcode 15.0 or later (for building from source)

## Building the App

1. **Clone or Download** this project
2. **Run the build script**:
   ```bash
   ./build.sh
   ```
3. **Launch the app**:
   ```bash
   open ./build/Build/Products/Release/TodoPlantApp.app
   ```

Alternatively, open `TodoPlantApp.xcodeproj` in Xcode and build normally.

## Screenshots

The app features a clean, two-panel interface:
- **Left Panel**: Todo list with add/delete/complete functionality
- **Right Panel**: Plant display with growth progress and plant selection

## Technical Details

- **Framework**: SwiftUI
- **Platform**: macOS (native app)
- **Architecture**: MVVM pattern with ObservableObject
- **Persistence**: In-memory (resets on app restart)
- **Timer**: Uses Foundation Timer for countdown functionality

## Future Enhancements

Potential features for future versions:
- [ ] Data persistence between app launches
- [ ] Achievement system
- [ ] Multiple plant gardens
- [ ] Sound effects and animations
- [ ] Export completed task statistics
- [ ] Plant care reminders

## License

This project is open source. Feel free to modify and distribute!

---

**Enjoy growing your virtual plants while staying productive! 🌱✅**
