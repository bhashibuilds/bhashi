// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TodoPlantApp",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .executable(name: "TodoPlantApp", targets: ["TodoPlantApp"])
    ],
    targets: [
        .executableTarget(
            name: "TodoPlantApp",
            path: "TodoPlantApp",
            sources: [
                "TodoPlantAppApp.swift",
                "ContentView.swift", 
                "TodoItem.swift",
                "PlantModel.swift",
                "PlantView.swift",
                "TodoListView.swift",
                "GameLogic.swift"
            ]
        )
    ]
)
