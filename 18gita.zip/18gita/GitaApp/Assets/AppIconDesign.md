# 18 Gita App Icon Design Concept

## Visual Elements for App Icon

### Primary Design
- **Base**: Circular mandala-style design with warm orange/golden gradient
- **Central Element**: Stylized "18" with Sanskrit-inspired typography
- **Background**: Lotus petal pattern in subtle gradients
- **Border**: Elegant golden rim with small decorative elements

### Color Scheme
```swift
// App Icon Colors
Primary Orange: #FF6B35
Golden Yellow: #FFD23F
Deep Saffron: #FF9933
Warm Cream: #FFF8DC
Sacred Red: #DC143C
```

### Icon Sizes Needed for iOS
- 1024x1024 (App Store)
- 180x180 (@3x iPhone)
- 120x120 (@2x iPhone)
- 87x87 (@3x iPhone Settings)
- 58x58 (@2x iPhone Settings)
- 80x80 (@2x iPad Settings)
- 40x40 (@1x iPad Settings)

## How to Create the App Icon

### Option 1: Using SF Symbols (Temporary)
For development/testing, use built-in symbols:
```swift
// In Assets.xcassets, create AppIcon set
// Use book.closed.fill with orange tint as placeholder
```

### Option 2: Custom Design (Recommended)
1. Create in design tool (Figma, Sketch, Photoshop)
2. Use the color scheme above
3. Include spiritual elements:
   - Lotus petals
   - Om symbol (subtle)
   - Sacred geometry
   - "18" prominently featured

### Option 3: Text-based Icon
- Large "18" in elegant serif font
- Sanskrit "गीता" below
- Orange to golden gradient background
- Subtle texture or pattern overlay

## Implementation in Xcode
1. Open Assets.xcassets
2. Add new "AppIcon" image set
3. Drag and drop icon files for each size
4. Ensure all required sizes are filled

## Widget Icon
- Simplified version of main app icon
- Focus on "18" numeral
- High contrast for small sizes
- Same color scheme
