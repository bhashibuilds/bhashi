# 18 Gita App Visual Assets

This directory contains the visual assets for the 18 Gita iOS app.

## App Icons Needed
- App Icon (various sizes for iOS)
- Widget icons
- Tab bar icons
- Navigation icons

## Background Images
- Spiritual/meditation backgrounds
- Gradient overlays
- Texture patterns

## UI Elements
- Custom buttons
- Card backgrounds
- Decorative elements

## Color Scheme
- Primary: Orange (#FF6B35)
- Secondary: Golden Yellow (#FFD23F)
- Background: Warm cream (#FFF8DC)
- Text: Dark brown (#8B4513)

## Implementation Notes
- All assets should be provided in @1x, @2x, and @3x resolutions
- Use vector graphics (SF Symbols) where possible
- Maintain spiritual/meditative theme throughout
