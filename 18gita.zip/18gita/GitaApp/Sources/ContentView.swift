import SwiftUI

struct ContentView: View {
    @StateObject private var verseManager = GitaVerseManager()
    @State private var showFullVerse = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Enhanced background with spiritual theme
                ZStack {
                    // Base gradient
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color(red: 1.0, green: 0.97, blue: 0.86), // Warm cream
                            Color(red: 1.0, green: 0.94, blue: 0.78)  // Light golden
                        ]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    
                    // Subtle pattern overlay
                    GeometryReader { geometry in
                        ForEach(0..<20, id: \.self) { _ in
                            Circle()
                                .fill(Color.orange.opacity(0.02))
                                .frame(width: 20, height: 20)
                                .position(
                                    x: CGFloat.random(in: 0...geometry.size.width),
                                    y: CGFloat.random(in: 0...geometry.size.height)
                                )
                        }
                    }
                }
                .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Enhanced Header with spiritual elements
                        VStack(spacing: 12) {
                            // Lotus-inspired icon group
                            ZStack {
                                Circle()
                                    .fill(
                                        RadialGradient(
                                            gradient: Gradient(colors: [
                                                Color.orange.opacity(0.3),
                                                Color.orange.opacity(0.1)
                                            ]),
                                            center: .center,
                                            startRadius: 0,
                                            endRadius: 40
                                        )
                                    )
                                    .frame(width: 80, height: 80)
                                
                                Image(systemName: "book.closed.fill")
                                    .font(.system(size: 35))
                                    .foregroundStyle(
                                        LinearGradient(
                                            gradient: Gradient(colors: [Color.orange, Color.red.opacity(0.8)]),
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                    )
                            }
                            
                            Text("🕉 18 Gita")
                                .font(.system(size: 32, weight: .bold, design: .serif))
                                .foregroundStyle(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color(red: 0.8, green: 0.4, blue: 0.0), // Deep orange
                                            Color(red: 0.6, green: 0.3, blue: 0.0)  // Darker orange
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                            
                            Text("Daily Wisdom from Bhagavad Gita")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                        }
                        .padding(.top, 20)
                        
                        // Enhanced Action Buttons
                        VStack(spacing: 16) {
                            // Date indicator with enhanced styling
                            HStack {
                                Image(systemName: "calendar")
                                    .foregroundColor(.orange.opacity(0.7))
                                Text("Today • \(Date().formatted(date: .abbreviated, time: .omitted))")
                                    .font(.system(.caption, design: .rounded))
                                    .foregroundColor(.secondary)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(
                                Capsule()
                                    .fill(Color.orange.opacity(0.1))
                            )
                        }
                        
                        // Main Verse Card
                        GitaVerseCard(verse: verseManager.currentVerse, isExpanded: $showFullVerse)
                            .padding(.horizontal)
                        
                        // Action buttons with improved design
                        HStack(spacing: 20) {
                            // Random Verse Button
                            Button(action: {
                                withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                                    let randomVerse = verseManager.getRandomVerse()
                                    verseManager.currentVerse = randomVerse
                                }
                            }) {
                                VStack(spacing: 8) {
                                    Image(systemName: "shuffle.circle.fill")
                                        .font(.title2)
                                        .foregroundStyle(
                                            LinearGradient(
                                                gradient: Gradient(colors: [Color.white, Color.white.opacity(0.9)]),
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                    
                                    Text("Random")
                                        .font(.system(.caption, design: .rounded))
                                        .fontWeight(.medium)
                                        .foregroundColor(.white)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.orange,
                                            Color.red.opacity(0.8)
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                                .shadow(color: .orange.opacity(0.4), radius: 8, x: 0, y: 4)
                            }
                            
                            // Share Button
                            Button(action: {
                                withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                                    shareVerse()
                                }
                            }) {
                                VStack(spacing: 8) {
                                    Image(systemName: "heart.circle.fill")
                                        .font(.title2)
                                        .foregroundStyle(
                                            LinearGradient(
                                                gradient: Gradient(colors: [Color.orange, Color.red.opacity(0.8)]),
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                    
                                    Text("Share")
                                        .font(.system(.caption, design: .rounded))
                                        .fontWeight(.medium)
                                        .foregroundColor(.orange)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.orange.opacity(0.1),
                                            Color.yellow.opacity(0.05)
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(
                                            LinearGradient(
                                                gradient: Gradient(colors: [Color.orange.opacity(0.3), Color.yellow.opacity(0.2)]),
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            ),
                                            lineWidth: 1
                                        )
                                )
                                .shadow(color: .orange.opacity(0.2), radius: 4, x: 0, y: 2)
                            }
                        }
                        .padding(.horizontal)
                        
                        Spacer(minLength: 20)
                    }
                }
            }
            .navigationBarHidden(true)
            .onAppear {
                verseManager.updateDailyVerse()
            }
        }
    }
    
    private func shareVerse() {
        let verse = verseManager.currentVerse
        let shareText = """
        \(verse.fullReference)
        
        \(verse.english)
        
        \(verse.meaning)
        
        - From 18Gita App
        """
        
        let activityController = UIActivityViewController(
            activityItems: [shareText],
            applicationActivities: nil
        )
        
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.rootViewController?.present(activityController, animated: true)
        }
    }
}

struct GitaVerseCard: View {
    let verse: GitaVerse
    @Binding var isExpanded: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Enhanced Reference Header
            HStack {
                HStack(spacing: 8) {
                    // Decorative icon
                    Image(systemName: "leaf.fill")
                        .font(.caption)
                        .foregroundColor(.orange.opacity(0.7))
                    
                    Text(verse.fullReference)
                        .font(.system(.headline, design: .serif))
                        .foregroundStyle(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.orange, Color.red.opacity(0.8)]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .fontWeight(.semibold)
                    
                    Image(systemName: "leaf.fill")
                        .font(.caption)
                        .foregroundColor(.orange.opacity(0.7))
                        .scaleEffect(x: -1, y: 1) // Mirror the leaf
                }
                
                Spacer()
                
                Button(action: {
                    withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                        isExpanded.toggle()
                    }
                }) {
                    Image(systemName: isExpanded ? "chevron.up.circle.fill" : "chevron.down.circle.fill")
                        .font(.title3)
                        .foregroundStyle(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.orange, Color.yellow]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                }
            }
            
            // Sanskrit (if expanded) with enhanced styling
            if isExpanded {
                VStack(alignment: .leading, spacing: 12) {
                    // Sanskrit Section
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "textformat.alt")
                                .font(.caption)
                                .foregroundColor(.orange.opacity(0.7))
                            Text("Sanskrit:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .fontWeight(.semibold)
                        }
                        
                        Text(verse.sanskrit)
                            .font(.system(.body, design: .serif))
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.leading)
                            .padding(.leading, 16)
                            .padding(.vertical, 8)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.orange.opacity(0.05))
                            )
                    }
                    
                    // Transliteration Section
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "textformat.abc")
                                .font(.caption)
                                .foregroundColor(.orange.opacity(0.7))
                            Text("Transliteration:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .fontWeight(.semibold)
                        }
                        
                        Text(verse.transliteration)
                            .font(.body)
                            .foregroundColor(.primary)
                            .italic()
                            .multilineTextAlignment(.leading)
                            .padding(.leading, 16)
                            .padding(.vertical, 8)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.blue.opacity(0.05))
                            )
                    }
                }
                .transition(.asymmetric(
                    insertion: .opacity.combined(with: .move(edge: .top)),
                    removal: .opacity.combined(with: .move(edge: .top))
                ))
            }
            
            // Enhanced English Translation
            VStack(alignment: .leading, spacing: 8) {
                if isExpanded {
                    HStack {
                        Image(systemName: "text.quote")
                            .font(.caption)
                            .foregroundColor(.orange.opacity(0.7))
                        Text("Translation:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .fontWeight(.semibold)
                    }
                }
                
                Text(verse.english)
                    .font(.system(.body, design: .default))
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(isExpanded ? nil : 3)
                    .padding(.leading, isExpanded ? 16 : 0)
                    .padding(.vertical, isExpanded ? 8 : 0)
                    .background(
                        isExpanded ? 
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.green.opacity(0.05)) : nil
                    )
            }
            
            // Enhanced Meaning Section
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: "lightbulb.fill")
                        .font(.caption)
                        .foregroundColor(.yellow.opacity(0.8))
                    Text("Meaning:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .fontWeight(.semibold)
                }
                
                Text(verse.meaning)
                    .font(.system(.callout, design: .default))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(isExpanded ? nil : 2)
                    .padding(.leading, 16)
                    .padding(.vertical, 8)
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.purple.opacity(0.05))
                    )
            }
        }
        .padding(20)
        .background(
            ZStack {
                // Main card background
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color(.systemBackground))
                
                // Decorative border
                RoundedRectangle(cornerRadius: 20)
                    .stroke(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.orange.opacity(0.3),
                                Color.yellow.opacity(0.2),
                                Color.orange.opacity(0.3)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1
                    )
                
                // Subtle inner shadow effect
                RoundedRectangle(cornerRadius: 20)
                    .fill(
                        RadialGradient(
                            gradient: Gradient(colors: [
                                Color.clear,
                                Color.orange.opacity(0.02)
                            ]),
                            center: .center,
                            startRadius: 0,
                            endRadius: 200
                        )
                    )
            }
        )
        .shadow(color: .orange.opacity(0.15), radius: 12, x: 0, y: 6)
        .shadow(color: .black.opacity(0.05), radius: 2, x: 0, y: 1)
        .animation(.spring(response: 0.6, dampingFraction: 0.8), value: isExpanded)
    }
}

#Preview {
    ContentView()
}
