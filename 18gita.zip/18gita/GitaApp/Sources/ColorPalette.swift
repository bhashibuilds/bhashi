import SwiftUI
import Foundation

// MARK: - 18 Gita App Color Palette
// Spiritual and warm color scheme inspired by traditional Hindu aesthetics

extension Color {
    
    // MARK: - Primary Colors
    static let gitaPrimary = Color(red: 1.0, green: 0.42, blue: 0.21) // #FF6B35 - Vibrant Orange
    static let gitaSecondary = Color(red: 1.0, green: 0.82, blue: 0.25) // #FFD23F - Golden Yellow
    static let gitaAccent = Color(red: 1.0, green: 0.6, blue: 0.2) // #FF9933 - Deep Saffron
    
    // MARK: - Background Colors
    static let gitaBackground = Color(red: 1.0, green: 0.97, blue: 0.86) // #FFF8DC - Warm Cream
    static let gitaBackgroundLight = Color(red: 1.0, green: 0.94, blue: 0.78) // Light Golden
    static let gitaCardBackground = Color(.systemBackground)
    
    // MARK: - Text Colors
    static let gitaTextPrimary = Color(red: 0.55, green: 0.27, blue: 0.07) // #8B4513 - Saddle Brown
    static let gitaTextSecondary = Color.secondary
    static let gitaTextAccent = Color.gitaPrimary
    
    // MARK: - Sacred Colors
    static let gitaSacredRed = Color(red: 0.86, green: 0.08, blue: 0.24) // #DC143C - Crimson
    static let gitaLotus = Color(red: 1.0, green: 0.71, blue: 0.76) // #FFB6C1 - Light Pink
    static let gitaOm = Color(red: 0.8, green: 0.4, blue: 0.0) // Deep Orange
    
    // MARK: - Functional Colors
    static let gitaSuccess = Color(red: 0.0, green: 0.7, blue: 0.3) // #00B04F - Success Green
    static let gitaWarning = Color(red: 1.0, green: 0.8, blue: 0.0) // #FFCC00 - Warning Yellow
    static let gitaError = Color(red: 0.9, green: 0.2, blue: 0.2) // #E53E3E - Error Red
    
    // MARK: - Gradient Definitions
    static let gitaPrimaryGradient = LinearGradient(
        gradient: Gradient(colors: [Color.gitaPrimary, Color.gitaAccent]),
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    
    static let gitaSecondaryGradient = LinearGradient(
        gradient: Gradient(colors: [Color.gitaSecondary, Color.gitaPrimary.opacity(0.8)]),
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    
    static let gitaBackgroundGradient = LinearGradient(
        gradient: Gradient(colors: [Color.gitaBackground, Color.gitaBackgroundLight]),
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    
    static let gitaCardGradient = LinearGradient(
        gradient: Gradient(colors: [
            Color.gitaPrimary.opacity(0.3),
            Color.gitaSecondary.opacity(0.2),
            Color.gitaPrimary.opacity(0.3)
        ]),
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    
    // MARK: - Shadow Colors
    static let gitaShadowPrimary = Color.gitaPrimary.opacity(0.15)
    static let gitaShadowSecondary = Color.black.opacity(0.05)
    static let gitaShadowButton = Color.gitaPrimary.opacity(0.4)
}

// MARK: - Usage Examples
/*
 
 // Background
 .background(Color.gitaBackgroundGradient)
 
 // Primary Button
 .background(Color.gitaPrimaryGradient)
 .foregroundColor(.white)
 
 // Secondary Button
 .background(Color.gitaSecondary.opacity(0.1))
 .foregroundColor(.gitaPrimary)
 
 // Card Background
 .background(Color.gitaCardBackground)
 .overlay(
     RoundedRectangle(cornerRadius: 16)
         .stroke(Color.gitaCardGradient, lineWidth: 1)
 )
 
 // Text Styling
 .foregroundColor(.gitaTextPrimary) // Primary text
 .foregroundColor(.gitaTextSecondary) // Secondary text
 .foregroundStyle(Color.gitaPrimaryGradient) // Gradient text
 
 // Shadows
 .shadow(color: .gitaShadowPrimary, radius: 12, x: 0, y: 6)
 .shadow(color: .gitaShadowSecondary, radius: 2, x: 0, y: 1)
 
 */
