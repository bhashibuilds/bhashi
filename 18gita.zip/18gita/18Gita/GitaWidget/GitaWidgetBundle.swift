//
//  GitaWidgetBundle.swift
//  GitaWidget
//
//  Created by Bhashini Yasam on 8/22/25.
//

import WidgetKit
import SwiftUI

@main
struct GitaWidgetBundle: WidgetBundle {
    var body: some Widget {
        GitaWidget()
    }
}
