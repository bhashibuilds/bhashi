//
//  GitaWidget.swift
//  GitaWidget
//
//  Created by Bhashini Yasam on 8/22/25.
//

import WidgetKit
import SwiftUI

struct GitaWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> GitaWidgetEntry {
        GitaWidgetEntry(date: Date(), verse: GitaVerse.sample)
    }

    func getSnapshot(in context: Context, completion: @escaping (GitaWidgetEntry) -> ()) {
        let entry = GitaWidgetEntry(date: Date(), verse: GitaVerse.sample)
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        let currentDate = Date()
        let verseManager = GitaVerseManager()
        
        // Update daily at midnight
        let calendar = Calendar.current
        let nextMidnight = calendar.nextDate(after: currentDate, matching: DateComponents(hour: 0, minute: 0), matchingPolicy: .nextTime) ?? currentDate.addingTimeInterval(86400)
        
        let entry = GitaWidgetEntry(
            date: currentDate,
            verse: verseManager.getDailyVerse(for: currentDate)
        )
        
        let timeline = Timeline(entries: [entry], policy: .after(nextMidnight))
        completion(timeline)
    }
}

struct GitaWidgetEntry: TimelineEntry {
    let date: Date
    let verse: GitaVerse
}

struct GitaWidgetEntryView: View {
    var entry: GitaWidgetProvider.Entry

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background gradient
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.orange.opacity(0.3),
                        Color.yellow.opacity(0.2)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                
                VStack(alignment: .leading, spacing: 8) {
                    // Header
                    HStack {
                        Image(systemName: "book.fill")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.orange)
                        
                        Text("18 Gita")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.primary)
                        
                        Spacer()
                        
                        Text("Today")
                            .font(.system(size: 10))
                            .foregroundColor(.secondary)
                    }
                    
                    // Verse Reference
                    Text(entry.verse.fullReference)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.orange)
                        .lineLimit(1)
                    
                    // Verse Text
                    Text(entry.verse.english)
                        .font(.system(size: 11))
                        .foregroundColor(.primary)
                        .lineLimit(geometry.size.height > 150 ? 4 : 3)
                        .multilineTextAlignment(.leading)
                    
                    if geometry.size.height > 150 {
                        // Meaning (only for medium/large widgets)
                        Text(entry.verse.meaning)
                            .font(.system(size: 10))
                            .foregroundColor(.secondary)
                            .lineLimit(2)
                            .multilineTextAlignment(.leading)
                    }
                    
                    Spacer()
                }
                .padding(12)
            }
        }
        .containerBackground(for: .widget) {
            Color.clear
        }
    }
}

struct GitaWidget: Widget {
    let kind: String = "GitaWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: GitaWidgetProvider()) { entry in
            GitaWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("Daily Gita Verse")
        .description("Display daily verses from the Bhagavad Gita on your home screen.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

#Preview(as: .systemSmall) {
    GitaWidget()
} timeline: {
    GitaWidgetEntry(date: .now, verse: GitaVerse.sample)
}

#Preview(as: .systemMedium) {
    GitaWidget()
} timeline: {
    GitaWidgetEntry(date: .now, verse: GitaVerse.sample)
}
