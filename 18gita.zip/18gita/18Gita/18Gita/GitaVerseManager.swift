import Foundation

struct GitaVerse: Codable, Identifiable {
    let id: Int
    let chapter: Int
    let verse: Int
    let sanskrit: String
    let transliteration: String
    let english: String
    let meaning: String
    
    var fullReference: String {
        return "Bhagavad Gita \(chapter).\(verse)"
    }
    
    var shortReference: String {
        return "\(chapter).\(verse)"
    }
    
    static let sample = GitaVerse(
        id: 1,
        chapter: 2,
        verse: 47,
        sanskrit: "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥",
        transliteration: "karmaṇy-evādhikāras te mā phaleṣhu kadāchana mā karma-phala-hetur bhūr mā te saṅgo 'stv akarmaṇi",
        english: "You have a right to perform your prescribed duty, but not to the fruits of action. Never consider yourself the cause of the results of your activities, and never be attached to not doing your duty.",
        meaning: "This famous verse teaches the principle of Nishkama Karma - performing one's duty without attachment to the results."
    )
}

class GitaVerseManager: ObservableObject {
    @Published var currentVerse: GitaVerse
    @Published var allVerses: [GitaVerse] = []
    
    private let userDefaults = UserDefaults.standard
    private let lastDateKey = "lastVerseDate"
    private let currentVerseKey = "currentVerse"
    
    init() {
        // Initialize with a default verse
        self.currentVerse = GitaVerse(
            id: 1,
            chapter: 2,
            verse: 47,
            sanskrit: "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥",
            transliteration: "karmaṇy-evādhikāras te mā phaleṣhu kadāchana mā karma-phala-hetur bhūr mā te saṅgo 'stv akarmaṇi",
            english: "You have a right to perform your prescribed duty, but not to the fruits of action. Never consider yourself the cause of the results of your activities, and never be attached to not doing your duty.",
            meaning: "This famous verse teaches the principle of Nishkama Karma - performing one's duty without attachment to the results. It emphasizes acting righteously while surrendering the outcomes to the divine."
        )
        
        loadVerses()
        updateDailyVerse()
    }
    
    private func loadVerses() {
        allVerses = createSampleVerses()
    }
    
    func updateDailyVerse() {
        let today = Calendar.current.startOfDay(for: Date())
        let lastDate = userDefaults.object(forKey: lastDateKey) as? Date ?? Date.distantPast
        
        if !Calendar.current.isDate(today, inSameDayAs: lastDate) {
            let newVerse = getVerseForDate(today)
            currentVerse = newVerse
            
            userDefaults.set(today, forKey: lastDateKey)
            if let encoded = try? JSONEncoder().encode(newVerse) {
                userDefaults.set(encoded, forKey: currentVerseKey)
            }
        } else {
            if let data = userDefaults.data(forKey: currentVerseKey),
               let savedVerse = try? JSONDecoder().decode(GitaVerse.self, from: data) {
                currentVerse = savedVerse
            }
        }
    }
    
    private func getVerseForDate(_ date: Date) -> GitaVerse {
        let dayOfYear = Calendar.current.ordinality(of: .day, in: .year, for: date) ?? 1
        let index = (dayOfYear - 1) % allVerses.count
        return allVerses[index]
    }
    
    func getRandomVerse() -> GitaVerse {
        return allVerses.randomElement() ?? currentVerse
    }
    
    func getDailyVerse(for date: Date) -> GitaVerse {
        let dayOfYear = Calendar.current.ordinality(of: .day, in: .year, for: date) ?? 1
        let index = (dayOfYear - 1) % allVerses.count
        return allVerses[index]
    }
    
    private func createSampleVerses() -> [GitaVerse] {
        return [
            GitaVerse(
                id: 1,
                chapter: 2,
                verse: 47,
                sanskrit: "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥",
                transliteration: "karmaṇy-evādhikāras te mā phaleṣhu kadāchana mā karma-phala-hetur bhūr mā te saṅgo 'stv akarmaṇi",
                english: "You have a right to perform your prescribed duty, but not to the fruits of action. Never consider yourself the cause of the results of your activities, and never be attached to not doing your duty.",
                meaning: "This famous verse teaches the principle of Nishkama Karma - performing one's duty without attachment to the results."
            ),
            GitaVerse(
                id: 2,
                chapter: 4,
                verse: 7,
                sanskrit: "यदा यदा हि धर्मस्य ग्लानिर्भवति भारत। अभ्युत्थानमधर्मस्य तदात्मानं सृजाम्यहम्॥",
                transliteration: "yadā yadā hi dharmasya glānir bhavati bhārata abhyutthānam adharmasya tadātmānaṁ sṛjāmy aham",
                english: "Whenever there is a decline in righteousness and an increase in unrighteousness, at that time I manifest myself on earth.",
                meaning: "Krishna explains the divine purpose of his incarnations - to restore dharma when it declines."
            ),
            GitaVerse(
                id: 3,
                chapter: 3,
                verse: 35,
                sanskrit: "श्रेयान्स्वधर्मो विगुणः परधर्मात्स्वनुष्ठितात्। स्वधर्मे निधनं श्रेयः परधर्मो भयावहः॥",
                transliteration: "śhreyān sva-dharmo viguṇaḥ para-dharmāt sv-anuṣhṭhitāt sva-dharme nidhanaṁ śhreyaḥ para-dharmo bhayāvahaḥ",
                english: "Better is one's own duty, though imperfectly performed, than the duty of another well performed. Better is death in one's own duty; the duty of another is fraught with danger.",
                meaning: "This verse emphasizes following one's own dharma rather than imitating others, even if done imperfectly."
            ),
            GitaVerse(
                id: 4,
                chapter: 6,
                verse: 5,
                sanskrit: "उद्धरेदात्मनात्मानं नात्मानमवसादयेत्। आत्मैव ह्यात्मनो बन्धुरात्मैव रिपुरात्मनः॥",
                transliteration: "uddhared ātmanātmānaṁ nātmānam avasādayet ātmaiva hy ātmano bandhur ātmaiva ripur ātmanaḥ",
                english: "One must deliver himself with the help of his mind, and not degrade himself. The mind is the friend of the conditioned soul, and his enemy as well.",
                meaning: "The mind can be our greatest ally or worst enemy - it depends on how we train and direct it."
            ),
            GitaVerse(
                id: 5,
                chapter: 15,
                verse: 7,
                sanskrit: "ममैवांशो जीवलोके जीवभूतः सनातनः। मनःषष्ठानीन्द्रियाणि प्रकृतिस्थानि कर्षति॥",
                transliteration: "mamaivāṁśho jīva-loke jīva-bhūtaḥ sanātanaḥ manaḥ-ṣhaṣhṭhānīndriyāṇi prakṛiti-sthāni karṣhati",
                english: "The living entities in this conditioned world are My eternal fragmental parts. Due to conditioned life, they are struggling very hard with the six senses, which include the mind.",
                meaning: "All living beings are eternal parts of the divine, struggling with material nature through the senses and mind."
            ),
            GitaVerse(
                id: 6,
                chapter: 18,
                verse: 66,
                sanskrit: "सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज। अहं त्वां सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः॥",
                transliteration: "sarva-dharmān parityajya mām ekaṁ śharaṇaṁ vraja ahaṁ tvāṁ sarva-pāpebhyo mokṣhayiṣhyāmi mā śhuchaḥ",
                english: "Abandon all varieties of religion and just surrender unto Me. I shall deliver you from all sinful reactions. Do not fear.",
                meaning: "The ultimate teaching of the Gita - complete surrender to the divine brings liberation from all suffering."
            )
        ]
    }
}
