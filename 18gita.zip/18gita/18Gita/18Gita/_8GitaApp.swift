//
//  _8GitaApp.swift
//  18Gita
//
//  Created by Bhashini Yasam on 8/22/25.
//

import SwiftUI

@main
struct _8GitaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
