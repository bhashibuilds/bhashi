import SwiftUI

struct ContentView: View {
    @StateObject private var verseManager = GitaVerseManager()
    @State private var showFullVerse = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background gradient
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.orange.opacity(0.1),
                        Color.yellow.opacity(0.1)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Header
                        VStack(spacing: 8) {
                            Image(systemName: "book.fill")
                                .font(.system(size: 40))
                                .foregroundColor(.orange)
                            
                            Text("18 Gita")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                                .foregroundColor(.primary)
                            
                            Text("Daily Verse from Bhagavad Gita")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        .padding(.top, 20)
                        
                        // Today's Date
                        Text("Today • \(Date().formatted(date: .abbreviated, time: .omitted))")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.horizontal)
                        
                        // Main Verse Card
                        GitaVerseCard(verse: verseManager.currentVerse, isExpanded: $showFullVerse)
                            .padding(.horizontal)
                        
                        // Action Buttons
                        HStack(spacing: 16) {
                            Button(action: {
                                let randomVerse = verseManager.getRandomVerse()
                                verseManager.currentVerse = randomVerse
                            }) {
                                Label("Random Verse", systemImage: "shuffle")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.orange)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                shareVerse()
                            }) {
                                Label("Share", systemImage: "square.and.arrow.up")
                                    .foregroundColor(.orange)
                                    .padding()
                                    .background(Color.orange.opacity(0.1))
                                    .cornerRadius(10)
                            }
                        }
                        .padding(.horizontal)
                        
                        Spacer(minLength: 20)
                    }
                }
            }
            .navigationBarHidden(true)
            .onAppear {
                verseManager.updateDailyVerse()
            }
        }
    }
    
    private func shareVerse() {
        let verse = verseManager.currentVerse
        let shareText = """
        \(verse.fullReference)
        
        \(verse.english)
        
        \(verse.meaning)
        
        - From 18Gita App
        """
        
        let activityController = UIActivityViewController(
            activityItems: [shareText],
            applicationActivities: nil
        )
        
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.rootViewController?.present(activityController, animated: true)
        }
    }
}

struct GitaVerseCard: View {
    let verse: GitaVerse
    @Binding var isExpanded: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Reference
            HStack {
                Text(verse.fullReference)
                    .font(.headline)
                    .foregroundColor(.orange)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Button(action: {
                    withAnimation(.easeInOut) {
                        isExpanded.toggle()
                    }
                }) {
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .foregroundColor(.orange)
                }
            }
            
            // Sanskrit (if expanded)
            if isExpanded {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Sanskrit:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .fontWeight(.semibold)
                    
                    Text(verse.sanskrit)
                        .font(.body)
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                    
                    Text("Transliteration:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .fontWeight(.semibold)
                        .padding(.top, 8)
                    
                    Text(verse.transliteration)
                        .font(.body)
                        .foregroundColor(.primary)
                        .italic()
                        .multilineTextAlignment(.leading)
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
            
            // English Translation
            VStack(alignment: .leading, spacing: 8) {
                if isExpanded {
                    Text("Translation:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .fontWeight(.semibold)
                }
                
                Text(verse.english)
                    .font(.body)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(isExpanded ? nil : 3)
            }
            
            // Meaning
            VStack(alignment: .leading, spacing: 8) {
                Text("Meaning:")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .fontWeight(.semibold)
                
                Text(verse.meaning)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(isExpanded ? nil : 2)
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.systemBackground))
                .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
        )
        .animation(.easeInOut, value: isExpanded)
    }
}

#Preview {
    ContentView()
}
