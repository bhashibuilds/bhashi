# Pixel Tamagotchi Game 

A nostalgic pixelated virtual pet game that lives on your computer! Take care of your digital companion by feeding, playing, and keeping them healthy.




1. Install pygame:
   ```bash
   python3 -m pip install pygame
   ```
2. Run the game:
   ```bash
   python3 tamagotchi_game.py
   ```


