#!/usr/bin/env python3
"""
Pixel Tamagotchi Game Launcher
Simple launcher with dependency checking
"""

import sys
import subprocess
import os

def check_pygame():
    """Check if pygame is installed"""
    try:
        import pygame
        return True
    except ImportError:
        return False

def install_pygame():
    """Install pygame using pip"""
    print("Installing pygame...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pygame"])
        return True
    except subprocess.CalledProcessError:
        return False

def main():
    print("🎮 Pixel Tamagotchi Game Launcher 🎮")
    print("=====================================")
    
    # Check Python version
    if sys.version_info < (3, 6):
        print("❌ Python 3.6 or higher is required!")
        print(f"Current version: {sys.version}")
        sys.exit(1)
    
    print(f"✅ Python version: {sys.version.split()[0]}")
    
    # Check pygame
    if not check_pygame():
        print("❌ pygame is not installed")
        print("Attempting to install pygame...")
        
        if install_pygame():
            print("✅ pygame installed successfully!")
        else:
            print("❌ Failed to install pygame")
            print("Please install manually: python3 -m pip install pygame")
            sys.exit(1)
    else:
        print("✅ pygame is available")
    
    # Launch game
    print("\n🚀 Starting Pixel Tamagotchi...")
    print("Close the game window to exit.")
    print("Your pet's progress will be automatically saved!")
    print("=" * 50)
    
    try:
        # Import and run the game
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from tamagotchi_game import Game
        
        game = Game()
        game.run()
        
    except KeyboardInterrupt:
        print("\n👋 Thanks for playing!")
    except Exception as e:
        print(f"\n❌ Error running game: {e}")
        print("Make sure tamagotchi_game.py is in the same directory.")

if __name__ == "__main__":
    main()
