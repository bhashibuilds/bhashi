import pygame
import sys
import time
import json
import os
from enum import Enum
from datetime import datetime, timedelta

# Initialize Pygame
pygame.init()

# Constants
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 500
FPS = 60

# Colors (pixelated palette)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
DARK_GREEN = (34, 139, 34)
LIGHT_GREEN = (144, 238, 144)
BROWN = (139, 69, 19)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GRAY = (128, 128, 128)
LIGHT_GRAY = (211, 211, 211)
PINK = (255, 192, 203)

class PetState(Enum):
    HAPPY = "happy"
    HUNGRY = "hungry"
    SLEEPY = "sleepy"
    SICK = "sick"
    DEAD = "dead"
    PLAYING = "playing"
    SLEEPING = "sleeping"

class Tamagotchi:
    def __init__(self):
        self.name = "Pixel"
        self.age_days = 0
        self.hunger = 50  # 0-100, 0 is starving
        self.happiness = 70  # 0-100
        self.health = 80  # 0-100
        self.energy = 60  # 0-100
        self.last_update = datetime.now()
        self.state = PetState.HAPPY
        self.is_sleeping = False
        self.sleep_start = None
        
        # Game state
        self.experience = 0
        self.level = 1
        
    def update(self):
        """Update pet stats based on time passed"""
        now = datetime.now()
        time_diff = (now - self.last_update).total_seconds() / 60  # minutes
        
        if time_diff >= 1:  # Update every minute
            # Decrease stats over time
            self.hunger = max(0, self.hunger - time_diff * 0.5)
            self.happiness = max(0, self.happiness - time_diff * 0.3)
            self.energy = max(0, self.energy - time_diff * 0.4)
            
            # Health affected by other stats
            if self.hunger < 20 or self.happiness < 20:
                self.health = max(0, self.health - time_diff * 0.8)
            elif self.hunger > 80 and self.happiness > 80:
                self.health = min(100, self.health + time_diff * 0.2)
                
            # Age progression
            age_minutes = (now - datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds() / 60
            self.age_days = int(age_minutes / 1440)  # 1440 minutes in a day
            
            # Level up based on experience
            required_exp = self.level * 100
            if self.experience >= required_exp:
                self.level += 1
                self.experience = 0
                
            self.last_update = now
            self.update_state()
    
    def update_state(self):
        """Update pet state based on stats"""
        if self.health <= 0:
            self.state = PetState.DEAD
        elif self.is_sleeping:
            self.state = PetState.SLEEPING
        elif self.health < 30:
            self.state = PetState.SICK
        elif self.hunger < 30:
            self.state = PetState.HUNGRY
        elif self.energy < 20:
            self.state = PetState.SLEEPY
        elif self.happiness > 70:
            self.state = PetState.HAPPY
        else:
            self.state = PetState.HAPPY
    
    def feed(self):
        """Feed the pet"""
        if self.state != PetState.DEAD:
            self.hunger = min(100, self.hunger + 25)
            self.happiness = min(100, self.happiness + 5)
            self.experience += 10
            
    def play(self):
        """Play with the pet"""
        if self.state != PetState.DEAD and self.energy > 20:
            self.happiness = min(100, self.happiness + 20)
            self.energy = max(0, self.energy - 15)
            self.experience += 15
            self.state = PetState.PLAYING
            
    def sleep(self):
        """Put pet to sleep or wake up"""
        if self.state != PetState.DEAD:
            if not self.is_sleeping:
                self.is_sleeping = True
                self.sleep_start = datetime.now()
            else:
                if self.sleep_start:
                    sleep_duration = (datetime.now() - self.sleep_start).total_seconds() / 60
                    self.energy = min(100, self.energy + sleep_duration * 2)
                self.is_sleeping = False
                self.sleep_start = None
                
    def heal(self):
        """Heal the pet (medicine)"""
        if self.state != PetState.DEAD:
            self.health = min(100, self.health + 30)
            self.experience += 5

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Pixel Tamagotchi")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 24)
        self.small_font = pygame.font.Font(None, 18)
        self.pet = Tamagotchi()
        self.load_game()
        
        # Animation variables
        self.animation_frame = 0
        self.animation_timer = 0
        
    def save_game(self):
        """Save game state to file"""
        save_data = {
            'name': self.pet.name,
            'age_days': self.pet.age_days,
            'hunger': self.pet.hunger,
            'happiness': self.pet.happiness,
            'health': self.pet.health,
            'energy': self.pet.energy,
            'experience': self.pet.experience,
            'level': self.pet.level,
            'last_update': self.pet.last_update.isoformat(),
            'is_sleeping': self.pet.is_sleeping
        }
        
        try:
            with open('tamagotchi_save.json', 'w') as f:
                json.dump(save_data, f)
        except Exception as e:
            print(f"Could not save game: {e}")
    
    def load_game(self):
        """Load game state from file"""
        try:
            if os.path.exists('tamagotchi_save.json'):
                with open('tamagotchi_save.json', 'r') as f:
                    save_data = json.load(f)
                
                self.pet.name = save_data.get('name', 'Pixel')
                self.pet.age_days = save_data.get('age_days', 0)
                self.pet.hunger = save_data.get('hunger', 50)
                self.pet.happiness = save_data.get('happiness', 70)
                self.pet.health = save_data.get('health', 80)
                self.pet.energy = save_data.get('energy', 60)
                self.pet.experience = save_data.get('experience', 0)
                self.pet.level = save_data.get('level', 1)
                self.pet.is_sleeping = save_data.get('is_sleeping', False)
                
                # Parse last update time
                last_update_str = save_data.get('last_update')
                if last_update_str:
                    self.pet.last_update = datetime.fromisoformat(last_update_str)
                    
        except Exception as e:
            print(f"Could not load save file: {e}")
    
    def draw_pixel_pet(self, x, y):
        """Draw the pixelated pet sprite"""
        size = 4  # Pixel size multiplier
        
        # Choose colors based on state
        if self.pet.state == PetState.DEAD:
            body_color = GRAY
            eye_color = BLACK
        elif self.pet.state == PetState.SICK:
            body_color = LIGHT_GRAY
            eye_color = RED
        elif self.pet.state == PetState.SLEEPING or self.pet.is_sleeping:
            body_color = PINK
            eye_color = BLACK
        elif self.pet.state == PetState.HAPPY or self.pet.state == PetState.PLAYING:
            body_color = LIGHT_GREEN
            eye_color = BLACK
        else:
            body_color = YELLOW
            eye_color = BLACK
        
        # Animation for playing state
        bounce = 0
        if self.pet.state == PetState.PLAYING:
            bounce = int(5 * abs(pygame.math.Vector2(0, 1).rotate(self.animation_frame * 10).y))
        
        pet_y = y - bounce
        
        # Body (oval shape made of rectangles)
        body_pixels = [
            (2, 0), (3, 0), (4, 0), (5, 0),
            (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1),
            (0, 2), (1, 2), (2, 2), (3, 2), (4, 2), (5, 2), (6, 2), (7, 2),
            (0, 3), (1, 3), (2, 3), (3, 3), (4, 3), (5, 3), (6, 3), (7, 3),
            (0, 4), (1, 4), (2, 4), (3, 4), (4, 4), (5, 4), (6, 4), (7, 4),
            (1, 5), (2, 5), (3, 5), (4, 5), (5, 5), (6, 5),
            (2, 6), (3, 6), (4, 6), (5, 6)
        ]
        
        for px, py in body_pixels:
            pygame.draw.rect(self.screen, body_color, 
                           (x + px * size, pet_y + py * size, size, size))
        
        # Eyes
        if not (self.pet.is_sleeping):
            # Left eye
            pygame.draw.rect(self.screen, eye_color, 
                           (x + 2 * size, pet_y + 2 * size, size, size))
            # Right eye
            pygame.draw.rect(self.screen, eye_color, 
                           (x + 5 * size, pet_y + 2 * size, size, size))
        else:
            # Sleeping eyes (lines)
            pygame.draw.rect(self.screen, eye_color, 
                           (x + 2 * size, pet_y + 2 * size + size//2, size, size//2))
            pygame.draw.rect(self.screen, eye_color, 
                           (x + 5 * size, pet_y + 2 * size + size//2, size, size//2))
        
        # Mouth based on happiness
        if self.pet.happiness > 50:
            # Happy mouth
            pygame.draw.rect(self.screen, eye_color, 
                           (x + 3 * size, pet_y + 4 * size, size * 2, size))
        else:
            # Sad mouth
            pygame.draw.rect(self.screen, eye_color, 
                           (x + 3 * size, pet_y + 5 * size, size * 2, size))
    
    def draw_stat_bar(self, x, y, width, height, value, max_value, color):
        """Draw a stat bar"""
        # Background
        pygame.draw.rect(self.screen, GRAY, (x, y, width, height))
        
        # Fill based on value
        fill_width = int((value / max_value) * width)
        pygame.draw.rect(self.screen, color, (x, y, fill_width, height))
        
        # Border
        pygame.draw.rect(self.screen, BLACK, (x, y, width, height), 2)
    
    def draw_button(self, x, y, width, height, text, color=LIGHT_GRAY):
        """Draw a clickable button"""
        pygame.draw.rect(self.screen, color, (x, y, width, height))
        pygame.draw.rect(self.screen, BLACK, (x, y, width, height), 2)
        
        text_surface = self.small_font.render(text, True, BLACK)
        text_rect = text_surface.get_rect(center=(x + width//2, y + height//2))
        self.screen.blit(text_surface, text_rect)
        
        return pygame.Rect(x, y, width, height)
    
    def handle_click(self, pos, buttons):
        """Handle button clicks"""
        for i, (rect, action) in enumerate(buttons):
            if rect.collidepoint(pos):
                action()
                break
    
    def run(self):
        """Main game loop"""
        running = True
        
        while running:
            dt = self.clock.tick(FPS)
            self.animation_timer += dt
            if self.animation_timer >= 100:  # Update animation every 100ms
                self.animation_frame += 1
                self.animation_timer = 0
            
            # Update pet
            self.pet.update()
            
            # Handle events
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.save_game()
                    running = False
                
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # Left click
                        # Define buttons
                        buttons = [
                            (pygame.Rect(50, 350, 60, 30), self.pet.feed),
                            (pygame.Rect(120, 350, 60, 30), self.pet.play),
                            (pygame.Rect(190, 350, 60, 30), self.pet.sleep),
                            (pygame.Rect(260, 350, 60, 30), self.pet.heal)
                        ]
                        
                        self.handle_click(event.pos, buttons)
            
            # Clear screen
            self.screen.fill(WHITE)
            
            # Draw background pattern
            for x in range(0, WINDOW_WIDTH, 20):
                for y in range(0, WINDOW_HEIGHT, 20):
                    if (x + y) % 40 == 0:
                        pygame.draw.rect(self.screen, LIGHT_GRAY, (x, y, 10, 10))
            
            # Draw pet info
            info_y = 20
            name_text = self.font.render(f"Name: {self.pet.name}", True, BLACK)
            self.screen.blit(name_text, (20, info_y))
            
            age_text = self.small_font.render(f"Age: {self.pet.age_days} days", True, BLACK)
            self.screen.blit(age_text, (20, info_y + 25))
            
            level_text = self.small_font.render(f"Level: {self.pet.level} (XP: {self.pet.experience})", True, BLACK)
            self.screen.blit(level_text, (20, info_y + 45))
            
            state_text = self.small_font.render(f"State: {self.pet.state.value.title()}", True, BLACK)
            self.screen.blit(state_text, (20, info_y + 65))
            
            # Draw stat bars
            bar_y = 100
            bar_height = 15
            bar_width = 150
            
            # Hunger
            hunger_label = self.small_font.render("Hunger:", True, BLACK)
            self.screen.blit(hunger_label, (20, bar_y))
            self.draw_stat_bar(100, bar_y, bar_width, bar_height, self.pet.hunger, 100, LIGHT_GREEN)
            
            # Happiness
            happiness_label = self.small_font.render("Happy:", True, BLACK)
            self.screen.blit(happiness_label, (20, bar_y + 25))
            self.draw_stat_bar(100, bar_y + 25, bar_width, bar_height, self.pet.happiness, 100, YELLOW)
            
            # Health
            health_label = self.small_font.render("Health:", True, BLACK)
            self.screen.blit(health_label, (20, bar_y + 50))
            self.draw_stat_bar(100, bar_y + 50, bar_width, bar_height, self.pet.health, 100, RED)
            
            # Energy
            energy_label = self.small_font.render("Energy:", True, BLACK)
            self.screen.blit(energy_label, (20, bar_y + 75))
            self.draw_stat_bar(100, bar_y + 75, bar_width, bar_height, self.pet.energy, 100, BLUE)
            
            # Draw pet
            self.draw_pixel_pet(160, 220)
            
            # Draw action buttons
            feed_btn = self.draw_button(50, 350, 60, 30, "Feed", LIGHT_GREEN)
            play_btn = self.draw_button(120, 350, 60, 30, "Play", YELLOW)
            sleep_btn = self.draw_button(190, 350, 60, 30, "Sleep", BLUE)
            heal_btn = self.draw_button(260, 350, 60, 30, "Medicine", PINK)
            
            # Draw instructions
            instruction_text = self.small_font.render("Click buttons to care for your pet!", True, BLACK)
            self.screen.blit(instruction_text, (50, 400))
            
            # Status messages
            if self.pet.state == PetState.DEAD:
                death_text = self.font.render("Your pet has died! Take better care next time.", True, RED)
                self.screen.blit(death_text, (20, 420))
            elif self.pet.is_sleeping:
                sleep_text = self.small_font.render("Zzz... Your pet is sleeping.", True, BLUE)
                self.screen.blit(sleep_text, (20, 420))
            
            # Auto-save every 30 seconds
            if int(time.time()) % 30 == 0:
                self.save_game()
            
            pygame.display.flip()
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()
