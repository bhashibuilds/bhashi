#!/bin/bash

# Create desktop shortcut for Pixel Tamagotchi
GAME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DESKTOP_DIR="$HOME/Desktop"
SHORTCUT_NAME="Pixel Tamagotchi.command"

# Create the command file
cat > "$DESKTOP_DIR/$SHORTCUT_NAME" << EOF
#!/bin/bash
cd "$GAME_DIR"
python3 launch_tamagotchi.py
EOF

# Make it executable
chmod +x "$DESKTOP_DIR/$SHORTCUT_NAME"

echo "✅ Desktop shortcut created!"
echo "📍 Location: $DESKTOP_DIR/$SHORTCUT_NAME"
echo "🎮 Double-click the shortcut on your desktop to play!"
